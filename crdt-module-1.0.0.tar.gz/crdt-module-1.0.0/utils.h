//
// Created by zhuchen on 2019-04-25.
//

#ifndef XREDIS_CRDT_UTILS_H
#define XREDIS_CRDT_UTILS_H

long long mstime();

sds moduleString2Sds(RedisModuleString *argv);

#endif //XREDIS_CRDT_UTILS_H
