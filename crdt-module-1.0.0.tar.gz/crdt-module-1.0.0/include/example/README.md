# An Example Redis Module

This project is a simple redis module demonstrating basic API usage and `librmutil`. 

You can treat it as a basic module template. See the project's [README](../README.md) for more details. 